 Note, to compile and run, we will run:
    javac Game.java
    java Game

Users can move the pointer block (blue box) with the arrow keys on the keyboard to select letters.
The goal is to find letters that make up English words, at the moment, we are prototyping with animal names.
Users can press the space bar to select letters for a word they think they have found, and the blue-highlighted
letters will turn green. For submitting the selection, users can press the enter key, which we plan on
then comparing to the master list of animal names and verifying the submitted word's validity. 
